# Ravali Gonela — Personal Portfolio

A responsive personal portfolio website built with plain HTML, CSS, and JavaScript.

## Preview locally
Open `index.html` in a browser. An internet connection is needed for the Google Fonts; the site otherwise uses local files.

## Publish with GitHub Pages
1. Sign in to GitHub and create a new **public** repository named `YOUR-GITHUB-USERNAME.github.io`.
2. Upload `index.html`, `style.css`, `script.js`, and the `assets` folder to the repository root.
3. Open **Settings → Pages**. Under build and deployment, choose **Deploy from a branch**, select `main` and `/(root)`, then save.
4. Wait for GitHub Pages to publish. The URL will be `https://YOUR-GITHUB-USERNAME.github.io`.

## Personalize before publishing
- The resume download is currently a DOCX file at `assets/Ravali-Gonela-Resume.docx`.
- Contact information and experience were based on the supplied resume.
- Check dates and role details before publishing, especially any roles whose dates may overlap.
- Consider whether you want your phone number and personal email publicly visible. Remove them from `index.html` if you prefer contact through LinkedIn only.
- Project cards are summaries from the resume; add public project links or screenshots only when you have permission to share them.
